package JeuDeCombat;

public class ForceInvalideException extends Exception {
    public ForceInvalideException(String message) {

        super(message);
    }
}
